"""Benchmark sorting and threshold alternatives for LayerNorm LAMP.

The script implements the normalized LayerNorm selection constraint

    H(theta) = sum_i z_i 1{z_i >= theta} >= b,
    z_i = y_i**2 / ||y||_2**2,
    b = max(epsilon - 2 min_i z_i, 0).

Four methods are compared:

* sorting: exact greedy baseline;
* linear: equally spaced thresholds, searched from high to low;
* binary: value-space binary search (ceil(log2(n)) iterations by default);
* random_sample: threshold estimated from m = ceil(sqrt(n)) sampled values.

The default experiment writes raw and aggregated CSV files, a Markdown table,
and a multi-panel scaling plot. Run ``python lamp_threshold_benchmark.py -h``
for configurable sizes, trial counts, and algorithm parameters.
"""

# Imports
from __future__ import annotations

import argparse
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


METHOD_ORDER = ["sorting", "linear", "binary", "random_sample"]
METHOD_LABELS = {
    "sorting": "Sorting (greedy)",
    "linear": "Linear threshold",
    "binary": "Binary threshold",
    "random_sample": "Random-sample threshold",
}
DIST_LABELS = {
    "uniform": r"Uniform $U(-1,1)$",
    "normal_centered": r"Normal $\mathcal{N}(0,1)$",
    "normal_shifted": r"Normal $\mathcal{N}(1,1)$",
}


@dataclass
class SelectionResult:
    method: str
    runtime_ms: float
    selected_count: int
    selected_mass: float
    target_mass: float
    threshold: float
    feasible: bool


def layernorm_scores(y: np.ndarray) -> np.ndarray:
    """Return z_i = y_i^2 / ||y||_2^2 in float64."""
    squared = np.square(y, dtype=np.float64)
    total = float(squared.sum(dtype=np.float64))
    if not np.isfinite(total) or total <= 0.0:
        raise ValueError("y must have a finite, nonzero Euclidean norm")
    return squared / total


def target_mass(z_min: float, epsilon: float) -> float:
    """Mass b needed after accounting for the two-minimum term."""
    return max(float(epsilon) - 2.0 * float(z_min), 0.0)


def _timed_result(
    method: str,
    start_ns: int,
    count: int,
    mass: float,
    target: float,
    threshold: float,
    n: int,
) -> SelectionResult:
    # q != 1 is part of Proposition 3.1, so selecting every entry is not
    # considered a feasible threshold solution.
    feasible = bool(count < n and mass + 1e-14 >= target)
    return SelectionResult(
        method=method,
        runtime_ms=(time.perf_counter_ns() - start_ns) / 1e6,
        selected_count=int(count),
        selected_mass=float(mass),
        target_mass=float(target),
        threshold=float(threshold),
        feasible=feasible,
    )


def sorting_greedy(z: np.ndarray, epsilon: float) -> SelectionResult:
    # Exact greedy reference: sort z descending and take minimum prefix.
    start = time.perf_counter_ns()
    values = np.sort(z)[::-1]
    target = target_mass(values[-1], epsilon)

    if target <= 0.0:
        return _timed_result("sorting", start, 0, 0.0, target, math.inf, z.size)

    # Leave at least one entry unselected, as required by q != 1.
    cumulative = np.cumsum(values[:-1], dtype=np.float64)
    insertion = int(np.searchsorted(cumulative, target, side="left"))
    if insertion >= cumulative.size:
        count = z.size - 1
        mass = float(cumulative[-1]) if cumulative.size else 0.0
        theta = float(values[-2]) if z.size > 1 else math.inf
    else:
        count = insertion + 1
        mass = float(cumulative[insertion])
        theta = float(values[insertion])
    return _timed_result("sorting", start, count, mass, target, theta, z.size)


def _threshold_statistics(z: np.ndarray, theta: float) -> tuple[int, float]:
    if math.isinf(theta) and theta > 0:
        return 0, 0.0
    mask = z >= theta
    return int(np.count_nonzero(mask)), float(z[mask].sum(dtype=np.float64))


def linear_threshold(
    z: np.ndarray, epsilon: float, steps: int = 16
) -> SelectionResult:
    """Search an equally spaced value grid from max(z) towards min(z)."""
    start = time.perf_counter_ns()
    z_min = float(np.min(z))
    z_max = float(np.max(z))
    target = target_mass(z_min, epsilon)
    if target <= 0.0:
        return _timed_result("linear", start, 0, 0.0, target, math.inf, z.size)

    # theta > z_min guarantees that a global minimum stays unselected.
    lowest = float(np.nextafter(z_min, math.inf))
    if lowest > z_max:
        return _timed_result("linear", start, 0, 0.0, target, math.inf, z.size)

    last = (0, 0.0, z_max)
    for theta in np.linspace(z_max, lowest, num=steps, dtype=np.float64):
        count, mass = _threshold_statistics(z, float(theta))
        last = (count, mass, float(theta))
        if mass + 1e-14 >= target:
            break
    return _timed_result("linear", start, last[0], last[1], target, last[2], z.size)


def binary_threshold(
    z: np.ndarray, epsilon: float, iterations: int | None = None
) -> SelectionResult:
    #Find the largest feasible value threshold by fixed-iteration bisection.
    start = time.perf_counter_ns()
    z_min = float(np.min(z))
    z_max = float(np.max(z))
    target = target_mass(z_min, epsilon)
    if target <= 0.0:
        return _timed_result("binary", start, 0, 0.0, target, math.inf, z.size)

    low = float(np.nextafter(z_min, math.inf))
    if low > z_max:
        return _timed_result("binary", start, 0, 0.0, target, math.inf, z.size)

    low_count, low_mass = _threshold_statistics(z, low)
    if low_mass + 1e-14 < target:
        return _timed_result(
            "binary", start, low_count, low_mass, target, low, z.size
        )

    high_count, high_mass = _threshold_statistics(z, z_max)
    if high_mass + 1e-14 >= target:
        return _timed_result(
            "binary", start, high_count, high_mass, target, z_max, z.size
        )

    if iterations is None:
        iterations = max(1, math.ceil(math.log2(z.size)))
    for _ in range(iterations):
        midpoint = (low + z_max) / 2.0
        count, mass = _threshold_statistics(z, midpoint)
        if mass + 1e-14 >= target:
            low, low_count, low_mass = midpoint, count, mass
        else:
            z_max = midpoint

    return _timed_result(
        "binary", start, low_count, low_mass, target, low, z.size
    )


def random_sample_threshold(
    z: np.ndarray,
    epsilon: float,
    rng: np.random.Generator,
    sample_size: int | None = None,
    sample_exponent: float = 0.5,
) -> SelectionResult:
    #Estimate the threshold using a uniform sample without replacement.
    start = time.perf_counter_ns()
    n = z.size
    z_min = float(np.min(z))
    target = target_mass(z_min, epsilon)
    if target <= 0.0:
        return _timed_result(
            "random_sample", start, 0, 0.0, target, math.inf, n
        )

    m = sample_size if sample_size is not None else math.ceil(n**sample_exponent)
    m = min(max(int(m), 1), n)
    indices = rng.choice(n, size=m, replace=False, shuffle=False)
    sample = np.sort(z[indices])[::-1]
    estimated_cumulative = (n / m) * np.cumsum(sample, dtype=np.float64)
    insertion = int(np.searchsorted(estimated_cumulative, target, side="left"))
    insertion = min(insertion, m - 1)
    theta = float(sample[insertion])

    # This exact full-vector pass is both the application of theta and the
    # validation proposed in the thesis text. No repair/fallback is applied,
    # so the empirical feasibility rate remains visible.
    count, mass = _threshold_statistics(z, theta)
    return _timed_result(
        "random_sample", start, count, mass, target, theta, n
    )


def generate_y(name: str, n: int, rng: np.random.Generator) -> np.ndarray:
    # Generate one of the three default prenormalization distributions.
    if name == "uniform":
        return rng.uniform(-1.0, 1.0, size=n)
    if name == "normal_centered":
        return rng.normal(0.0, 1.0, size=n)
    if name == "normal_shifted":
        return rng.normal(1.0, 1.0, size=n)
    raise ValueError(f"Unknown distribution: {name}")


def warm_up() -> None:
    # Prime NumPy code paths so first-call overhead is not in the benchmark
    rng = np.random.default_rng(0)
    z = layernorm_scores(rng.normal(size=256))
    sorting_greedy(z, 0.2)
    linear_threshold(z, 0.2, steps=4)
    binary_threshold(z, 0.2, iterations=4)
    random_sample_threshold(z, 0.2, rng, sample_size=16)


def run_benchmark(args: argparse.Namespace) -> pd.DataFrame:
    records: list[dict[str, float | int | str | bool]] = []
    master = np.random.SeedSequence(args.seed)
    total_cases = len(args.distributions) * len(args.ns) * args.trials
    seeds = iter(master.spawn(total_cases * 2))
    case_number = 0

    for distribution in args.distributions:
        for n in args.ns:
            for trial in range(args.trials):
                case_number += 1
                data_rng = np.random.default_rng(next(seeds))
                sample_seed = next(seeds)
                z = layernorm_scores(generate_y(distribution, n, data_rng))

                methods: list[tuple[str, Callable[[], SelectionResult]]] = [
                    ("sorting", lambda: sorting_greedy(z, args.epsilon)),
                    (
                        "linear",
                        lambda: linear_threshold(z, args.epsilon, args.linear_steps),
                    ),
                    (
                        "binary",
                        lambda: binary_threshold(
                            z, args.epsilon, args.binary_iterations
                        ),
                    ),
                    (
                        "random_sample",
                        lambda: random_sample_threshold(
                            z,
                            args.epsilon,
                            np.random.default_rng(sample_seed),
                            args.sample_size,
                            args.sample_exponent,
                        ),
                    ),
                ]

                # Rotate execution order to reduce systematic cache/order bias.
                offset = trial % len(methods)
                methods = methods[offset:] + methods[:offset]
                case_results = {name: fn() for name, fn in methods}
                exact_count = case_results["sorting"].selected_count

                for method in METHOD_ORDER:
                    result = case_results[method]
                    row = asdict(result)
                    row.update(
                        distribution=distribution,
                        n=n,
                        trial=trial,
                        selected_rate=result.selected_count / n,
                        mass_gap=result.selected_mass - result.target_mass,
                        abs_mass_gap=abs(result.selected_mass - result.target_mass),
                        selected_vs_sort=(
                            result.selected_count / exact_count
                            if exact_count > 0
                            else 1.0
                        ),
                        threshold_times_n=(
                            result.threshold * n
                            if np.isfinite(result.threshold)
                            else math.inf
                        ),
                    )
                    records.append(row)

            print(
                f"Completed {distribution:>15s}, n={n:>9,d} "
                f"({case_number}/{total_cases} cases)",
                flush=True,
            )
    return pd.DataFrame.from_records(records)


def summarize(raw: pd.DataFrame) -> pd.DataFrame:
    grouped = raw.groupby(["distribution", "n", "method"], sort=False)
    summary = grouped.agg(
        runtime_ms_mean=("runtime_ms", "mean"),
        runtime_ms_std=("runtime_ms", "std"),
        selected_rate_mean=("selected_rate", "mean"),
        selected_vs_sort_mean=("selected_vs_sort", "mean"),
        selected_mass_mean=("selected_mass", "mean"),
        target_mass_mean=("target_mass", "mean"),
        mass_gap_mean=("mass_gap", "mean"),
        abs_mass_gap_mean=("abs_mass_gap", "mean"),
        feasible_rate=("feasible", "mean"),
        threshold_times_n_mean=("threshold_times_n", "mean"),
    ).reset_index()
    summary["runtime_ms_std"] = summary["runtime_ms_std"].fillna(0.0)

    sort_times = (
        summary[summary["method"] == "sorting"]
        .set_index(["distribution", "n"])["runtime_ms_mean"]
        .rename("sorting_runtime_ms")
    )
    summary = summary.join(sort_times, on=["distribution", "n"])
    summary["speedup_vs_sort"] = (
        summary["sorting_runtime_ms"] / summary["runtime_ms_mean"]
    )
    return summary


def make_plot(summary: pd.DataFrame, output_path: Path, epsilon: float) -> None:
    distributions = list(summary["distribution"].drop_duplicates())
    
    fig, axes = plt.subplots(3, 3, figsize=(15, 4.1 * 3), squeeze=False)
    
    colors = dict(zip(METHOD_ORDER, plt.get_cmap("tab10").colors))
    markers = {"sorting": "o", "linear": "s", "binary": "^", "random_sample": "D"}

    for row_index, distribution in enumerate(distributions):
        # Prevent index out of bounds if there happen to be more than 3 distributions
        if row_index >= 3:
            break
            
        subset = summary[summary["distribution"] == distribution]
        for method in METHOD_ORDER:
            data = subset[subset["method"] == method].sort_values("n")
            common = dict(
                marker=markers[method],
                markersize=4,
                linewidth=1.7,
                color=colors[method],
                label=METHOD_LABELS[method],
            )
            axes[row_index, 0].plot(data["n"], data["runtime_ms_mean"], **common)
            axes[row_index, 1].plot(
                data["n"], data["selected_vs_sort_mean"], **common
            )
            axes[row_index, 2].plot(data["n"], data["mass_gap_mean"], **common)

        axes[row_index, 0].set_ylabel(
            f"{DIST_LABELS.get(distribution, distribution)}\nRuntime (ms)"
        )
        axes[row_index, 0].set_yscale("log")
        axes[row_index, 1].axhline(1.0, color="0.4", linestyle=":", linewidth=1)
        axes[row_index, 1].set_ylabel("Selected count / sorting")
        axes[row_index, 2].axhline(0.0, color="0.4", linestyle=":", linewidth=1)
        axes[row_index, 2].set_ylabel(r"Mass gap $H(\theta)-b$")
        
        for axis in axes[row_index]:
            axis.set_xscale("log")
            axis.grid(True, which="both", alpha=0.25)
            axis.set_xlabel("Vector size n")

    for axis, title in zip(
        axes[0],
        ["Computation time", "Sparsity vs. baseline", "Cumulative-mass error"],
    ):
        axis.set_title(title)

    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.973),
        ncol=4,
        frameon=False,
    )
    fig.suptitle(
        rf"LayerNorm LAMP threshold benchmark ($\epsilon={epsilon:g}$)", y=0.995
    )
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def write_markdown_table(summary: pd.DataFrame, path: Path) -> None:
    columns = [
        "distribution",
        "n",
        "method",
        "runtime_ms_mean",
        "speedup_vs_sort",
        "selected_rate_mean",
        "selected_vs_sort_mean",
        "mass_gap_mean",
        "abs_mass_gap_mean",
        "feasible_rate",
    ]
    renamed = {
        "distribution": "distribution",
        "n": "n",
        "method": "method",
        "runtime_ms_mean": "time_ms",
        "speedup_vs_sort": "speedup",
        "selected_rate_mean": "selected_rate",
        "selected_vs_sort_mean": "count/sort",
        "mass_gap_mean": "mass_gap",
        "abs_mass_gap_mean": "abs_mass_gap",
        "feasible_rate": "feasible_rate",
    }
    table = summary[columns].rename(columns=renamed).copy()
    table["distribution"] = table["distribution"].map(DIST_LABELS).fillna(
        table["distribution"]
    )
    table["method"] = table["method"].map(METHOD_LABELS).fillna(table["method"])
    float_cols = table.select_dtypes(include=[np.number]).columns.difference(["n"])
    table[float_cols] = table[float_cols].round(6)
    headers = [str(column) for column in table.columns]
    markdown_rows = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for values in table.itertuples(index=False, name=None):
        escaped = [str(value).replace("|", r"\|") for value in values]
        markdown_rows.append("| " + " | ".join(escaped) + " |")
    path.write_text(
        "# LayerNorm LAMP threshold benchmark\n\n"
        + "\n".join(markdown_rows)
        + "\n",
        encoding="utf-8",
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--ns",
        nargs="+",
        type=int,
        default=[1_000, 3_000, 10_000, 30_000, 100_000, 300_000],
        help="Vector sizes (default: 1k 3k 10k 30k 100k 300k)",
    )
    parser.add_argument("--trials", type=int, default=5, help="Trials per case")
    parser.add_argument(
        "--epsilon",
        type=float,
        default=0.2,
        help="Required normalized LAMP mass before the 2*min term",
    )
    parser.add_argument("--linear-steps", type=int, default=16)
    parser.add_argument(
        "--binary-iterations",
        type=int,
        default=None,
        help="Bisection iterations (default: ceil(log2(n)))",
    )
    parser.add_argument(
        "--sample-size",
        type=int,
        default=None,
        help="Fixed random-sample size (overrides --sample-exponent)",
    )
    parser.add_argument("--sample-exponent", type=float, default=0.5)
    parser.add_argument(
        "--distributions",
        nargs="+",
        choices=list(DIST_LABELS),
        default=list(DIST_LABELS),
    )
    parser.add_argument("--seed", type=int, default=20260719)
    parser.add_argument(
        "--output-dir", type=Path, default=Path("lamp_benchmark_results")
    )
    args = parser.parse_args()

    if any(n < 2 for n in args.ns):
        parser.error("all n values must be at least 2")
    if args.trials < 1:
        parser.error("--trials must be positive")
    if not 0.0 <= args.epsilon <= 2.0:
        parser.error("--epsilon must lie in [0, 2]")
    if args.linear_steps < 2:
        parser.error("--linear-steps must be at least 2")
    if args.binary_iterations is not None and args.binary_iterations < 1:
        parser.error("--binary-iterations must be positive")
    if args.sample_size is not None and args.sample_size < 1:
        parser.error("--sample-size must be positive")
    if not 0.0 < args.sample_exponent <= 1.0:
        parser.error("--sample-exponent must lie in (0, 1]")
    return args


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    warm_up()
    raw = run_benchmark(args)
    summary = summarize(raw)

    raw_path = args.output_dir / "lamp_threshold_trials.csv"
    summary_path = args.output_dir / "lamp_threshold_summary.csv"
    markdown_path = args.output_dir / "lamp_threshold_summary.md"
    plot_path = args.output_dir / "lamp_threshold_performance.png"
    raw.to_csv(raw_path, index=False)
    summary.to_csv(summary_path, index=False)
    write_markdown_table(summary, markdown_path)
    make_plot(summary, plot_path, args.epsilon)

    largest_n = max(args.ns)
    compact = summary[summary["n"] == largest_n][
        [
            "distribution",
            "method",
            "runtime_ms_mean",
            "selected_rate_mean",
            "selected_vs_sort_mean",
            "mass_gap_mean",
            "feasible_rate",
        ]
    ].copy()
    print(f"\nSummary at n={largest_n:,}:")
    print(compact.to_string(index=False, float_format=lambda value: f"{value:.6g}"))
    print(f"\nWrote results to {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
