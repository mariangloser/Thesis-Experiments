This folder contains all the code modifications that were used to generate the plots in the thesis.

lamp_threshold_benchmark.py is self contained and generates the plots comparing different threshold based alternatives to sorting.

The tau_scaling folder contains all the python files that were used to generate the plots related to threshold scaling in LAMP applied
to causal mask attention.