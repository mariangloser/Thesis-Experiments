from __future__ import annotations

import gc
import sys
import time
from pathlib import Path
from typing import Any

import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
BASELINE_DIR = ROOT / "src" / "baseline_github"
SCALING_DIR = ROOT / "src" / "scaling"
RESULTS_DIR = ROOT / "results"

sys.path.insert(0, str(BASELINE_DIR))
sys.path.insert(0, str(SCALING_DIR))

from token_provider import TokenFromTextProvider, stream_dataset_from_config
from exp_helper import (
    compute_perplexity,
    reset_model_lamp,
    reset_model_precision,
    set_seed,
    update_model_lamp,
    update_model_precision,
)
from weight_loader import get_gpt2_files
from gpt2_pretrained import load_pretrained_gpt2
from gpt2_lowprec import LowPrecGPT2Config, LowPrecGPT2Model

from gpt2_lamp_scaling import LampGPT2Config, LampGPT2Model
from scaling_helper import update_tau_scaling


SEED = 42

MODEL_TYPE = "gpt2-xl"
DATASET_NAME = "WikiText-2"
DATASET_SPLIT = "test"

SEQ_LEN = 1024
NBATCHES = 30
M_BITS = 4

BASE_TAUS = [0.03, 0.09]

ALPHAS = [
    0.00,
    0.10,
    0.20,
    0.30,
    0.40,
    0.50,
    0.60,
    0.70,
    0.80,
    0.90,
    1.00,
    1.10,
    1.20,
    1.30,
    1.40,
    1.50,
]


def create_token_provider() -> TokenFromTextProvider:
    dataset, text_column_name = stream_dataset_from_config(
        DATASET_NAME,
        split=DATASET_SPLIT,
    )

    return TokenFromTextProvider(
        dataset=dataset,
        batch_size=1,
        seq_len=SEQ_LEN,
        shuffle_tokens=False,
        text_column_name=text_column_name,
    )


def evaluate(
    *,
    variant: str,
    model: torch.nn.Module,
    token_provider: TokenFromTextProvider,
    base_tau: float | None = None,
    alpha: float | None = None,
) -> dict[str, Any]:
    print(
        f"\nEvaluating {variant}"
        f" | tau={base_tau}"
        f" | alpha={alpha}"
    )

    start_time = time.perf_counter()

    perplexity = compute_perplexity(
        model=model,
        token_provider=token_provider,
        max_batches=NBATCHES,
        use_pbar=True,
    )

    elapsed_seconds = time.perf_counter() - start_time

    if isinstance(model, LampGPT2Model):
        recomputation_rate = float(
            model.mean_sparsity().mean().item()
        )
    else:
        recomputation_rate = 0.0

    token_provider.reset()

    return {
        "variant": variant,
        "model": MODEL_TYPE,
        "dataset": DATASET_NAME,
        "split": DATASET_SPLIT,
        "seq_len": SEQ_LEN,
        "nbatches": NBATCHES,
        "m_bits": 23 if variant == "full_precision" else M_BITS,
        "base_tau": base_tau,
        "scaling_mode": (
            "power" if variant == "power" else None
        ),
        "alpha": alpha,
        "tau_max": None,
        "reference_length": (
            SEQ_LEN if variant == "power" else None
        ),
        "perplexity": float(perplexity),
        "recomputation_rate": recomputation_rate,
        "elapsed_seconds": elapsed_seconds,
    }


def add_selection_metrics(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()

    fp_rows = result[result["variant"] == "full_precision"]
    lp_rows = result[result["variant"] == "low_precision"]

    if len(fp_rows) != 1 or len(lp_rows) != 1:
        raise RuntimeError(
            "Expected exactly one full-precision row and "
            "one low-precision row."
        )

    fp_perplexity = float(fp_rows.iloc[0]["perplexity"])
    lp_perplexity = float(lp_rows.iloc[0]["perplexity"])

    denominator = lp_perplexity - fp_perplexity

    result["perplexity_increase_over_fp"] = (
        result["perplexity"] - fp_perplexity
    )

    if denominator > 0:
        result["recovery"] = (
            lp_perplexity - result["perplexity"]
        ) / denominator
    else:
        result["recovery"] = float("nan")

    result["recovery_percent"] = 100.0 * result["recovery"]

    result["efficiency"] = (
        result["recovery"]
        / result["recomputation_rate"].replace(0.0, float("nan"))
    )

    return result


def add_pareto_column(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()
    result["pareto_optimal"] = False

    power_indices = result.index[
        result["variant"] == "power"
    ].tolist()

    for index in power_indices:
        candidate = result.loc[index]

        dominated = False

        for other_index in power_indices:
            if other_index == index:
                continue

            other = result.loc[other_index]

            no_worse_perplexity = (
                other["perplexity"] <= candidate["perplexity"]
            )
            no_worse_recomputation = (
                other["recomputation_rate"]
                <= candidate["recomputation_rate"]
            )

            strictly_better = (
                other["perplexity"] < candidate["perplexity"]
                or other["recomputation_rate"]
                < candidate["recomputation_rate"]
            )

            if (
                no_worse_perplexity
                and no_worse_recomputation
                and strictly_better
            ):
                dominated = True
                break

        result.loc[index, "pareto_optimal"] = not dominated

    return result


def main() -> None:
    set_seed(SEED)

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required.")

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    output_path = RESULTS_DIR / "power_grid_search.csv"
    ranked_path = RESULTS_DIR / "power_grid_search_ranked.csv"

    print(f"CUDA device: {torch.cuda.get_device_name(0)}")
    print(f"Configurations: {len(BASE_TAUS) * len(ALPHAS)}")
    print(f"Batches per configuration: {NBATCHES}")

    weights_dir = ROOT / "weights"
    weights_dir.mkdir(parents=True, exist_ok=True)

    print("\nLoading model weights...")
    get_gpt2_files(MODEL_TYPE, str(weights_dir))

    reference_model = load_pretrained_gpt2(
        MODEL_TYPE,
        str(weights_dir),
    ).cuda().eval()

    reference_config = reference_model.config

    lowprec_config = LowPrecGPT2Config.from_vanilla(
        reference_config
    )

    lowprec_model = LowPrecGPT2Model(
        lowprec_config
    ).cuda().eval()

    lowprec_model.load_state_dict(
        reference_model.state_dict()
    )

    lamp_config = LampGPT2Config.from_lowprec(
        lowprec_config,
        relax_lamp=True,
        fake_lamp=False,
    )

    lamp_config.tau_scaling_mode = "power"
    lamp_config.tau_scaling_alpha = 0.0
    lamp_config.tau_scaling_max = None
    lamp_config.tau_reference_length = SEQ_LEN

    lamp_model = LampGPT2Model(
        lamp_config
    ).cuda().eval()

    lamp_model.load_state_dict(
        reference_model.state_dict()
    )

    reset_model_precision(lowprec_model)
    update_model_precision(
        lowprec_model,
        "m_bits_attn_score",
        M_BITS,
    )

    reset_model_precision(lamp_model)
    update_model_precision(
        lamp_model,
        "m_bits_attn_score",
        M_BITS,
    )

    print(f"\nLoading {DATASET_NAME}...")
    token_provider = create_token_provider()

    results: list[dict[str, Any]] = []

    try:
        results.append(
            evaluate(
                variant="full_precision",
                model=reference_model,
                token_provider=token_provider,
            )
        )

        results.append(
            evaluate(
                variant="low_precision",
                model=lowprec_model,
                token_provider=token_provider,
            )
        )

        for base_tau in BASE_TAUS:
            for alpha in ALPHAS:
                reset_model_lamp(lamp_model)

                update_model_lamp(
                    lamp_model,
                    "tau_softmax",
                    base_tau,
                )

                update_tau_scaling(
                    lamp_model,
                    mode="power",
                    alpha=alpha,
                    tau_max=None,
                    reference_length=SEQ_LEN,
                )

                row = evaluate(
                    variant="power",
                    model=lamp_model,
                    token_provider=token_provider,
                    base_tau=base_tau,
                    alpha=alpha,
                )

                results.append(row)

                # Save after each configuration.
                pd.DataFrame(results).to_csv(
                    output_path,
                    index=False,
                )

                print(
                    f"Result: PPL={row['perplexity']:.6f}, "
                    f"recomp={100 * row['recomputation_rate']:.3f}%"
                )

                gc.collect()
                torch.cuda.empty_cache()

    finally:
        token_provider.close()

    result_df = pd.DataFrame(results)
    result_df.to_csv(output_path, index=False)

    ranked_df = add_selection_metrics(result_df)
    ranked_df = add_pareto_column(ranked_df)

    ranked_df = ranked_df.sort_values(
        by=[
            "variant",
            "base_tau",
            "recomputation_rate",
            "perplexity",
        ],
        na_position="first",
    )

    ranked_df.to_csv(ranked_path, index=False)

    print("\nPower-law results:")
    print(
        ranked_df[
            ranked_df["variant"] == "power"
        ][
            [
                "base_tau",
                "alpha",
                "perplexity",
                "recomputation_rate",
                "recovery_percent",
                "efficiency",
                "pareto_optimal",
            ]
        ].to_string(index=False)
    )

    print(f"\nRaw results:    {output_path}")
    print(f"Ranked results: {ranked_path}")


if __name__ == "__main__":
    main()