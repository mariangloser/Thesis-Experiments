from __future__ import annotations

import gc
import sys
import time
from pathlib import Path
from typing import Any

import pandas as pd
import torch


ROOT = Path(__file__).resolve().parents[1]
BASELINE_DIR = ROOT / "src" / "baseline_github"
SCALING_DIR = ROOT / "src" / "scaling"
RESULTS_DIR = ROOT / "results"

# Experimental modules take precedence over the unchanged baseline.
sys.path.insert(0, str(BASELINE_DIR))
sys.path.insert(0, str(SCALING_DIR))

from token_provider import TokenFromTextProvider, stream_dataset_from_config
from exp_helper import (
    compute_perplexity,
    reset_model_lamp,
    reset_model_precision,
    set_seed,
    update_model_lamp,
    update_model_precision,
)
from weight_loader import get_gpt2_files
from gpt2_pretrained import load_pretrained_gpt2
from gpt2_lowprec import LowPrecGPT2Config, LowPrecGPT2Model

from gpt2_lamp_scaling import LampGPT2Config, LampGPT2Model
from scaling_helper import update_tau_scaling


SEED = 42

MODEL_TYPE = "gpt2-xl"
SEQ_LEN = 1024
NBATCHES = 100
M_BITS = 4


# These labels must match the names supported by
# stream_dataset_from_config in token_provider.py.
DATASETS = [
    {
        "name": "GSM8k Math",
        "split": "test",
    },
    {
        "name": "WikiText-2",
        "split": "test",
    },
    {
        "name": "CodeParrot",
        "split": "train",
    },
]


METHODS = [
    {
        "method": "Relaxed LAMP",
        "specification": "tau=0.03",
        "base_tau": 0.03,
        "scaling_mode": "constant",
        "alpha": 0.0,
        "tau_max": None,
        "is_ours": False,
    },
    {
        "method": "Relaxed LN",
        "specification": "tau=0.03, alpha=0.5",
        "base_tau": 0.03,
        "scaling_mode": "saturated_power",
        "alpha": 0.5,
        "tau_max": 1.0,
        "is_ours": False,
    },
    {
        "method": "Relaxed LAMP",
        "specification": "tau=0.09",
        "base_tau": 0.09,
        "scaling_mode": "constant",
        "alpha": 0.0,
        "tau_max": None,
        "is_ours": False,
    },
    {
        "method": "Relaxed LN",
        "specification": "tau=0.09, alpha=0.5",
        "base_tau": 0.09,
        "scaling_mode": "saturated_power",
        "alpha": 0.5,
        "tau_max": 1.0,
        "is_ours": False,
    },
    {
        "method": "Generalized power law",
        "specification": "tau=0.09, alpha=0.7",
        "base_tau": 0.09,
        "scaling_mode": "power",
        "alpha": 0.7,
        "tau_max": None,
        "is_ours": True,
    },
]


def create_token_provider(
    dataset_name: str,
    split: str,
) -> TokenFromTextProvider:
    dataset, text_column_name = stream_dataset_from_config(
        dataset_name,
        split=split,
    )

    return TokenFromTextProvider(
        dataset=dataset,
        batch_size=1,
        seq_len=SEQ_LEN,
        shuffle_tokens=False,
        text_column_name=text_column_name,
    )


def evaluate(
    *,
    dataset_name: str,
    dataset_split: str,
    method: str,
    specification: str,
    model: torch.nn.Module,
    token_provider: TokenFromTextProvider,
    m_bits: int,
    base_tau: float | None = None,
    scaling_mode: str | None = None,
    alpha: float | None = None,
    tau_max: float | None = None,
    is_ours: bool = False,
) -> dict[str, Any]:
    print(
        f"\nDataset: {dataset_name}"
        f"\nMethod:  {method}"
        f"\nConfig:  {specification}"
    )

    start_time = time.perf_counter()

    perplexity = compute_perplexity(
        model=model,
        token_provider=token_provider,
        max_batches=NBATCHES,
        use_pbar=True,
    )

    elapsed_seconds = time.perf_counter() - start_time

    if isinstance(model, LampGPT2Model):
        recomputation_rate = float(
            model.mean_sparsity().mean().item()
        )
    else:
        recomputation_rate = 0.0

    token_provider.reset()

    return {
        "dataset": dataset_name,
        "split": dataset_split,
        "method": method,
        "specification": specification,
        "is_ours": is_ours,
        "model": MODEL_TYPE,
        "seq_len": SEQ_LEN,
        "nbatches": NBATCHES,
        "m_bits": m_bits,
        "base_tau": base_tau,
        "scaling_mode": scaling_mode,
        "alpha": alpha,
        "tau_max": tau_max,
        "reference_length": (
            SEQ_LEN if scaling_mode is not None else None
        ),
        "perplexity": float(perplexity),
        "recomputation_rate": recomputation_rate,
        "recomputation_percent": 100.0 * recomputation_rate,
        "elapsed_seconds": elapsed_seconds,
    }


def add_dataset_metrics(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()

    result["perplexity_increase_over_fp"] = float("nan")
    result["recovery"] = float("nan")
    result["recovery_percent"] = float("nan")

    for dataset_name in result["dataset"].unique():
        dataset_mask = result["dataset"] == dataset_name
        dataset_rows = result[dataset_mask]

        fp_rows = dataset_rows[
            dataset_rows["method"] == "Full precision"
        ]
        lp_rows = dataset_rows[
            dataset_rows["method"] == "Low precision"
        ]

        if len(fp_rows) != 1 or len(lp_rows) != 1:
            raise RuntimeError(
                f"Expected exactly one FP and one LP row for "
                f"{dataset_name}."
            )

        fp_perplexity = float(
            fp_rows.iloc[0]["perplexity"]
        )
        lp_perplexity = float(
            lp_rows.iloc[0]["perplexity"]
        )

        degradation = lp_perplexity - fp_perplexity

        result.loc[
            dataset_mask,
            "perplexity_increase_over_fp",
        ] = (
            result.loc[dataset_mask, "perplexity"]
            - fp_perplexity
        )

        if degradation > 0:
            recovery = (
                lp_perplexity
                - result.loc[dataset_mask, "perplexity"]
            ) / degradation

            result.loc[
                dataset_mask,
                "recovery",
            ] = recovery

            result.loc[
                dataset_mask,
                "recovery_percent",
            ] = 100.0 * recovery

    return result


def save_results(
    results: list[dict[str, Any]],
    raw_path: Path,
    ranked_path: Path,
) -> None:
    raw_df = pd.DataFrame(results)
    raw_df.to_csv(raw_path, index=False)

    if raw_df.empty:
        return

    # Recovery metrics require completed FP and LP rows.
    completed_datasets: list[pd.DataFrame] = []

    for dataset_name in raw_df["dataset"].unique():
        dataset_df = raw_df[
            raw_df["dataset"] == dataset_name
        ]

        methods = set(dataset_df["method"])

        if {
            "Full precision",
            "Low precision",
        }.issubset(methods):
            completed_datasets.append(dataset_df)

    if not completed_datasets:
        return

    completed_df = pd.concat(
        completed_datasets,
        ignore_index=True,
    )

    ranked_df = add_dataset_metrics(completed_df)
    ranked_df.to_csv(ranked_path, index=False)


def print_dataset_results(
    results_df: pd.DataFrame,
    dataset_name: str,
) -> None:
    dataset_df = results_df[
        results_df["dataset"] == dataset_name
    ].copy()

    if dataset_df.empty:
        return

    display_columns = [
        "method",
        "specification",
        "perplexity",
        "recomputation_percent",
        "recovery_percent",
    ]

    available_columns = [
        column
        for column in display_columns
        if column in dataset_df.columns
    ]

    print(f"\n=== {dataset_name} ===")
    print(
        dataset_df[available_columns].to_string(
            index=False,
            float_format=lambda value: f"{value:.6f}",
        )
    )


def main() -> None:
    set_seed(SEED)

    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA is required for this experiment."
        )

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    raw_path = (
        RESULTS_DIR
        / "full_dataset_comparison_raw.csv"
    )
    ranked_path = (
        RESULTS_DIR
        / "full_dataset_comparison_ranked.csv"
    )

    print(f"CUDA device: {torch.cuda.get_device_name(0)}")
    print(f"Datasets: {len(DATASETS)}")
    print(f"Methods per dataset: {2 + len(METHODS)}")
    print(f"Batches per evaluation: {NBATCHES}")

    weights_dir = ROOT / "weights"
    weights_dir.mkdir(parents=True, exist_ok=True)

    print("\nLoading GPT-2 XL weights...")

    get_gpt2_files(
        MODEL_TYPE,
        str(weights_dir),
    )

    reference_model = load_pretrained_gpt2(
        MODEL_TYPE,
        str(weights_dir),
    ).cuda().eval()

    lowprec_config = LowPrecGPT2Config.from_vanilla(
        reference_model.config
    )

    lowprec_model = LowPrecGPT2Model(
        lowprec_config
    ).cuda().eval()

    lowprec_model.load_state_dict(
        reference_model.state_dict()
    )

    lamp_config = LampGPT2Config.from_lowprec(
        lowprec_config,
        relax_lamp=True,
        fake_lamp=False,
    )

    lamp_config.tau_scaling_mode = "constant"
    lamp_config.tau_scaling_alpha = 0.0
    lamp_config.tau_scaling_max = None
    lamp_config.tau_reference_length = SEQ_LEN

    lamp_model = LampGPT2Model(
        lamp_config
    ).cuda().eval()

    lamp_model.load_state_dict(
        reference_model.state_dict()
    )

    reset_model_precision(lowprec_model)
    update_model_precision(
        lowprec_model,
        "m_bits_attn_score",
        M_BITS,
    )

    reset_model_precision(lamp_model)
    update_model_precision(
        lamp_model,
        "m_bits_attn_score",
        M_BITS,
    )

    results: list[dict[str, Any]] = []

    for dataset_config in DATASETS:
        dataset_name = dataset_config["name"]
        dataset_split = dataset_config["split"]

        print(
            "\n"
            + "=" * 72
            + f"\nStarting dataset: {dataset_name}"
            + f"\nSplit: {dataset_split}"
            + "\n"
            + "=" * 72
        )

        token_provider = create_token_provider(
            dataset_name,
            dataset_split,
        )

        try:
            # Full-precision baseline.
            row = evaluate(
                dataset_name=dataset_name,
                dataset_split=dataset_split,
                method="Full precision",
                specification="N/A",
                model=reference_model,
                token_provider=token_provider,
                m_bits=23,
            )
            results.append(row)

            save_results(
                results,
                raw_path,
                ranked_path,
            )

            # Pure low-precision baseline.
            row = evaluate(
                dataset_name=dataset_name,
                dataset_split=dataset_split,
                method="Low precision",
                specification="N/A",
                model=lowprec_model,
                token_provider=token_provider,
                m_bits=M_BITS,
            )
            results.append(row)

            save_results(
                results,
                raw_path,
                ranked_path,
            )

            # Original LAMP variants and our generalized scaling law.
            for method_config in METHODS:
                reset_model_lamp(lamp_model)

                update_model_lamp(
                    lamp_model,
                    "tau_softmax",
                    method_config["base_tau"],
                )

                update_tau_scaling(
                    lamp_model,
                    mode=method_config["scaling_mode"],
                    alpha=method_config["alpha"],
                    tau_max=method_config["tau_max"],
                    reference_length=SEQ_LEN,
                )

                row = evaluate(
                    dataset_name=dataset_name,
                    dataset_split=dataset_split,
                    method=method_config["method"],
                    specification=method_config[
                        "specification"
                    ],
                    model=lamp_model,
                    token_provider=token_provider,
                    m_bits=M_BITS,
                    base_tau=method_config["base_tau"],
                    scaling_mode=method_config[
                        "scaling_mode"
                    ],
                    alpha=method_config["alpha"],
                    tau_max=method_config["tau_max"],
                    is_ours=method_config["is_ours"],
                )

                results.append(row)

                save_results(
                    results,
                    raw_path,
                    ranked_path,
                )

                print(
                    f"Result: "
                    f"PPL={row['perplexity']:.6f}, "
                    f"recomputation="
                    f"{row['recomputation_percent']:.3f}%"
                )

                gc.collect()
                torch.cuda.empty_cache()

        finally:
            token_provider.close()

        current_df = add_dataset_metrics(
            pd.DataFrame(results)
        )

        print_dataset_results(
            current_df,
            dataset_name,
        )

    final_df = add_dataset_metrics(
        pd.DataFrame(results)
    )

    final_df.to_csv(
        ranked_path,
        index=False,
    )

    print("\n" + "=" * 72)
    print("FINAL RESULTS")
    print("=" * 72)

    for dataset_config in DATASETS:
        print_dataset_results(
            final_df,
            dataset_config["name"],
        )

    print(f"\nRaw results:    {raw_path}")
    print(f"Ranked results: {ranked_path}")


if __name__ == "__main__":
    main()