from __future__ import annotations

from typing import Literal

import torch


ScalingMode = Literal[
    "constant",
    "power",
    "saturated_power",
]


def scale_tau(
    base_tau: float,
    row_lengths: torch.Tensor,
    mode: ScalingMode = "constant",
    alpha: float = 0.5,
    tau_max: float | None = None,
    reference_length: int = 1024,
) -> torch.Tensor:
    if base_tau < 0:
        raise ValueError("base_tau must be non-negative.")

    if alpha < 0:
        raise ValueError("alpha must be non-negative.")

    if reference_length <= 0:
        raise ValueError("reference_length must be positive.")

    if torch.any(row_lengths <= 0):
        raise ValueError("row_lengths must contain only positive values.")

    if mode == "constant":
        return torch.full_like(
            row_lengths,
            fill_value=float(base_tau),
            dtype=torch.float32,
        )

    scaled_tau = float(base_tau) * (
        float(reference_length) / row_lengths.to(torch.float32)
    ).pow(float(alpha))

    if mode == "power":
        return scaled_tau

    if mode == "saturated_power":
        if tau_max is None:
            raise ValueError(
                "tau_max must be provided for saturated_power."
            )

        if tau_max <= 0:
            raise ValueError("tau_max must be positive.")

        return torch.clamp(scaled_tau, max=float(tau_max))

    raise ValueError(
        f"Unknown scaling mode {mode!r}. "
        "Expected constant, power, or saturated_power."
    )
