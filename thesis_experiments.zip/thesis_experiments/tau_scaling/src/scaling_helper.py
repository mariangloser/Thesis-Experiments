from __future__ import annotations

from gpt2_lamp_scaling import LampGPT2Model


def update_tau_scaling(
    model: LampGPT2Model,
    mode: str,
    alpha: float = 0.5,
    tau_max: float | None = None,
    reference_length: int = 1024,
) -> None:
    """
    Update threshold-scaling settings on an already-created model.
    """
    model.config.tau_scaling_mode = mode
    model.config.tau_scaling_alpha = alpha
    model.config.tau_scaling_max = tau_max
    model.config.tau_reference_length = reference_length

    for block in model.h:
        block.attn.tau_scaling_mode = mode
        block.attn.tau_scaling_alpha = alpha
        block.attn.tau_scaling_max = tau_max
        block.attn.tau_reference_length = reference_length
