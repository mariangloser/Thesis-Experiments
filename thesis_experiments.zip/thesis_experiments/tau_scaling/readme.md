The baseline_github folder is a placeholder folder for the lamp code published in the github repository https://github.com/sbudzinskiy/LAMP-LLM to avoid redistribution of said code.

The src folder contains custom adjustments to the LAMP code that are used when performing the experiments.

The experiments folder contains 3 experiments that use the adjusted tau threshold scaling in the src folder. Namely, power grid search
for finding the optimal alpha (power_grid_search.py), saturation grid search for finding the optimal c (saturation_grid_search.py) and
a full dataset comparison, comparing the performance of the different methods.

If the dependencies form the above mention repository are inside the baseline_github folder, the experiment files should be able to run inside a conda environment also mentioned in the above repository.